import styles from "./Logo.css"

function Logo() {
    return (
        <h1 className="main-logo">savvy</h1>
    )
}
export default Logo;